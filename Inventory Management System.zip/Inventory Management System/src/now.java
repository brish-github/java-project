
//import com.sun.jdi.connect.spi.Connection;
import java.sql.*;
import java.util.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author user
 */
public class now {

    public static void main(String[] args) throws SQLException {
        String sil = "root";
        String pass = "root";
        String connection = "jdbc:mysql://localhost/user";
        Connection con = null;
System.out.println("enter you name");
Scanner scan = new Scanner(System.in);
String name=scan.nextLine();
System.out.println("enter your password");
String passw = scan.nextLine();
        
        con = DriverManager.getConnection(connection, sil, pass);
         String query = "select * from userinformation";
         Statement stmt=null;
        stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery(query);
         int k=0;
         while (rs.next()) {
              String temp = rs.getString("id");
           String po=rs.getString("password");
           if (name.equals(temp)&&passw.equals(po)){
               System.out.println("you loged in");
               k=1;
               break;
           }
          
          }
         if (k==0){
         
             System.out.println("you are not a customer");
         }
        
        
    }

}
