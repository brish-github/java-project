/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
import java.time.LocalDateTime; 
import javax.swing.*;
 */
package pharmacy;
import java.sql.*; 
import javax.swing.*;
import java.util.StringTokenizer;
/**
 *
 * @author user
 */
public class ExpireDateChecker extends parentClass {
     
    ExpireDateChecker(){
       
   
   String query = "select * from medicine_list";
   try{
       ResultSet result = statement.executeQuery(query);
       while(result.next()){
       String tempExpireDate = result.getString("expire_date");
       StringTokenizer st = new StringTokenizer(tempExpireDate,"-"); 
       String date[]=new String[3];
       //PreparedStatement prepare = preparStatement()
       int i=0;
     while (st.hasMoreTokens()) {
         date[i]=st.nextToken();  
         i++;
     }
     String tempid = result.getString("id");
     String queryDelete = "delete from medicine_list where id="+"\""+tempid+"\"";
    PreparedStatement prepared = con.prepareStatement(queryDelete);
   
     if(currentYear>(Integer.parseInt(date[0]))){
        
     prepared.executeUpdate();
   
     
     }
     else if(currentYear==(Integer.parseInt(date[0]))) {
         if(currentMonth>(Integer.parseInt(date[1]))){
                  prepared.execute();

         }}
     else if(currentYear==(Integer.parseInt(date[0]))) {
         if(currentMonth==(Integer.parseInt(date[1]))){
         if(currentDay>=(Integer.parseInt(date[2]))){
              prepared.execute();

             }}
     
     
     }
     
       
       }
   }
   catch(Exception e){
       JOptionPane.showMessageDialog(null,"error occured!");
  
   }
   }
   public static void main(String[]args){
  /*it jave nothing inside the main method, becuase the code is inside the constructon*/
   }

}
