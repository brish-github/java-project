/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;

/**
 *
 * @author user
 */
abstract class parentClass extends JFrame {

    Connection con = null;
    Statement statement = null;
    final static String url = "jdbc:mysql://localhost/user";
    final static String username = "root";
    final static String password = "root";
    DateTimeFormatter year = DateTimeFormatter.ofPattern("yyyy");
    DateTimeFormatter month = DateTimeFormatter.ofPattern("MM");
    DateTimeFormatter day = DateTimeFormatter.ofPattern("dd");
    LocalDateTime currentDate = LocalDateTime.now();
    int currentYear = Integer.parseInt(year.format(currentDate));
    int currentMonth = Integer.parseInt(month.format(currentDate));
    int currentDay = Integer.parseInt(day.format(currentDate));

    parentClass() {
        try {
            con = DriverManager.getConnection(url, username, password);
            statement = con.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }

    }

    static void exitMethod() {
        int res = JOptionPane.showOptionDialog(new JFrame(), "are you sure you want to exit?", "",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                new Object[]{"Yes", "No"}, JOptionPane.NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            System.exit(0);
        }

    }

}
